# Design Patterns exercises

This project contains exercises to practice the implementation of several design patterns.
