package io.github.nirlleypaixao.patterns.strategy;

import com.eriksencosta.money.Money;

import java.util.HashMap;
import java.util.Map;

public class Billing {
    // Adicionei um map de PlanPrincingStrategy para armazenar as associações entre nome do plano e sua estratégia.
    private static final Map<String, PlanPricingStrategy> pricingStrategies = new HashMap<>();

    static {
        pricingStrategies.put("Free", new FreePlanPricing());
        pricingStrategies.put("Basic", new BasicPlanPricing());
        pricingStrategies.put("Business", new BusinessPlanPricing());
        pricingStrategies.put("Enterprise", new EnterprisePlanPricing());

    }

    public Invoice invoice(Contract contract, Usage usage) {
        // Injeção de Dependência de PlanPricingStrategy
        PlanPricingStrategy pricingStrategy = getPricingStrategyForPlan(contract.plan);

        Money userCost = pricingStrategy.calculateUserCost(usage.users);
        Money storageCost = pricingStrategy.calculateStorageCost(usage.storageInGigabytes, usage.users);

        return new Invoice(contract.plan, usage.users, usage.storageInGigabytes, userCost, storageCost);
    }

    private PlanPricingStrategy getPricingStrategyForPlan(String plan) {
        PlanPricingStrategy strategy = pricingStrategies.get(plan);
        if (strategy == null) {
            throw new IllegalArgumentException("Plan does not exist: " + plan);
        }
        return strategy;
    }
}
