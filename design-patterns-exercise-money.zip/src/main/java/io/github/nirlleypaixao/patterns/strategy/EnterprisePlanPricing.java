package io.github.nirlleypaixao.patterns.strategy;

import com.eriksencosta.money.Money;

public class EnterprisePlanPricing implements PlanPricingStrategy {
    private static final Money NEGOTIATED_PRICE_PER_GB = Money.Factory.of(0.91, "USD");

    @Override
    public Money calculateUserCost(int users) {
        if (users > 10000) {
            return Money.Factory.of(135, "USD").times(users);
        } else if (users >= 100) {
            return Money.Factory.of(185, "USD").times(users);
        } else {
            throw new IllegalArgumentException("Too few users for enterprise plan");
        }
    }

    @Override
    public Money calculateStorageCost(int storageInGigabytes, int users) {
        // Calcula a cota de armazenamento gratuito (5GB por usuário)
        int freeStorage = users * 5;

        // Calcula o armazenamento excedente, se houve
        int excessStorageGB = Math.max(0, storageInGigabytes - freeStorage);

        // Retorna o custo do armazenamento excedente
        return NEGOTIATED_PRICE_PER_GB.times(excessStorageGB);
    }
}
