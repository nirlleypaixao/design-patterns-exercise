rootProject.name = "design-patterns-exercises"

